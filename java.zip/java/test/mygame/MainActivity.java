package test.mygame;

import android.app.*;
import android.os.*;
import bogo.kaayo.backend.*;

public class MainActivity extends BaseApplication{
	
    @Override
    protected void onCreate(Bundle savedInstanceState){
		startGame(new Game(),R.layout.main);
        super.onCreate(savedInstanceState);
    }
}
