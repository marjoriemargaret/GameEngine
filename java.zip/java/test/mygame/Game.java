package test.mygame;

import bogo.kaayo.*;
import bogo.kaayo.graphics.model.*;
import bogo.kaayo.graphics.*;
import bogo.kaayo.graphics.model.loader.*;
import java.io.*;
import bogo.kaayo.math.*;
import android.opengl.*;
import bogo.kaayo.input.*;
import java.util.*;
import bogo.kaayo.graphics.model.entities.*;
import bogo.kaayo.graphics.r2d.*;
import bogo.kaayo.input.InputListener.*;
import java.net.*;
import bogo.kaayo.graphics.model.post.*;
import bogo.kaayo.graphics.r2d.ui.*;
import bogo.kaayo.physics.*;
import bogo.kaayo.utils.*;
 
public class Game extends GameAdapter{
	ModelRenderer renderer;
	Camera cam;
	ModelEntity ship,terrain;
	Batch batch;
	BitmapFont font;
	Joystick joystick;
	
	@Override
	public void create(){
		try{
			Rb.input.addInputProcessor(this);
			cam = new Camera().setToPersp();
			cam.far = 1000f;


			//icc = new IsometricCameraController(c);
			renderer = new ModelRenderer();
			Light l = new Light(100,100,100);
			Model m = null;
			m = ObjLoader.load(Rb.files.device("game/ship.obj"));
			ship = new ModelEntity(m,l);

			batch = new Batch();
			font = new BitmapFont();
			//m = ObjLoader.load(Rb.files.device("game/test.obj"));
			m = new Terrain(Rb.files.device("game/textures/texturePack.json"),Rb.files.device("heightmap.png"));
			terrain = new ModelEntity(m,l);
			Joystick.Style style = new Joystick.Style(new Texture(Rb.files.device("game/pad.png")),new Texture(Rb.files.device("game/knob.png")),new Vector3f(100,100,0),75,40);
			joystick = new Joystick(style,0);
			style = new Joystick.Style(new Texture(Rb.files.device("game/pad.png")),new Texture(Rb.files.device("game/knob.png")),new Vector3f(500,100,0),100,50);
			//j2 = new Joystick(style,1);
			cam.translate(0,3,3);
			cam.lookAt(0,1,0);
		}catch(Exception e){
			throw new RbException(e);
		}
		Rb.GL20.glDisable(Rb.GL20.GL_DITHER);
	}
	
	float pitch;
	float yaw;
	@Override
	public void draw(){
		Rb.GL20.glClearColor(0.6f,0.6f,0.9f,1);
		Rb.GL20.glClear(Rb.GL20.GL_COLOR_BUFFER_BIT|Rb.GL20.GL_DEPTH_BUFFER_BIT);
		
		try{
			cam.update();
			renderer.begin(cam);
			renderer.render(ship);
			renderer.render(terrain);
			renderer.end();
			
			if(joystick.isTouched()){
				Vector3f v = new Vector3f(joystick.knobPercent.x,0,joystick.knobPercent.y).rotate(-pitch,0,1,0);
				ship.translate(v.x,0,-v.z);
			}
			cam.position.set(ship.position()).add(new Vector3f(0,3,3)./*rotate(yaw,1,0,0).*/rotate(pitch,0,1,0));
			
			batch.begin();
			joystick.draw(batch);
			font.draw(batch,0f,0f,2f,"FPS "+Rb.graphics.FPS());
			batch.end();
			
			pitch += smoothing.x * Rb.graphics.deltaTime();
			yaw += smoothing.y * Rb.graphics.deltaTime();
			//cam.rotate(smoothing.y * Rb.graphics.deltaTime(),1,0,0);
			cam.rotate(smoothing.x * Rb.graphics.deltaTime(),0,1,0);
			if(smoothing.x>0){
				smoothing.x -= 0.5f;
			}
			if(smoothing.x<0){
				smoothing.x += 0.5f;
			}
		}catch(Exception e){
			throw new RbException(e);
		}
	}
	
	@Override
	public void resize(int width, int height){
		cam.update(true,width,height);
	}
	
	private Queuevii<Vector3f> touchA = new Queuevii<Vector3f>(5);
	//private Queuevii<Vector3f> touchB = new Queuevii<Vector3f>(5);
	private Vector3f smoothing = new Vector3f();
	@Override
	public void touchDown(InputListener.Event e){
		int pI = 0;
		if(joystick.isTouched()) pI=1;
		float dy = 20;
		touchA.enqueue(new Vector3f(e.getX(pI),e.getY(pI),0));
		Vector3f dir = new Vector3f(touchA.getTail()).sub(touchA.getHead()).nor();
		smoothing.set((int)(dir.x*dy),(int)(dir.y*dy),0);
	}
	
}
