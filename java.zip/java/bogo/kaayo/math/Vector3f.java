package bogo.kaayo.math;

public class Vector3f{
	public float x;
	public float y;
	public float z;
	
	public boolean isZero(){
		return x+y+z==0;
	}
	
	public Vector3f(){
		set(0,0,0);
	}
	
	public Vector3f(Vector3f v){
		set(v.x,v.y,v.z);
	}
	
	public Vector3f(float x, float y, float z){
		set(x,y,z);
	}
	
	public Vector3f set(Vector3f v){
		return set(v.x,v.y,v.z);
	}
	
	public Vector3f set(float x, float y, float z){
		this.x = x;
		this.y = y;
		this.z = z;
		return this;
	}
	
	public Vector3f add(Vector3f v){
		return add(v.x,v.y,v.z);
	}
	
	public Vector3f add(float x, float y, float z){
		return set(this.x+x,this.y+y,this.z+z);
	}
	
	public Vector3f sub(Vector3f v){
		return sub(v.x,v.y,v.z);
	}
	
	public Vector3f sub(float x, float y, float z){
		return set(this.x-x,this.y-y,this.z-z);
	}
	
	public Vector3f mul(Vector3f v){
		return mul(v.x,v.y,v.z);
	}
	
	public Vector3f mul(float x, float y, float z){
		return set(this.x*x,this.y*y,this.z*z);
	}
	
	public Vector3f mul(float[] mat){
		return this.set(x * mat[Matrix4f.M00] + y * mat[Matrix4f.M01] + z * mat[Matrix4f.M02] + mat[Matrix4f.M03], x
						* mat[Matrix4f.M10] + y * mat[Matrix4f.M11] + z * mat[Matrix4f.M12] + mat[Matrix4f.M13], x * mat[Matrix4f.M20] + y
						* mat[Matrix4f.M21] + z * mat[Matrix4f.M22] + mat[Matrix4f.M23]);
	}
	
	public Vector3f crs(Vector3f v){
		return crs(v.x, v.y, v.z);
	}
	
	public Vector3f crs(float x, float y, float z){
		return set(this.y * z - this.z * y, this.z * x - this.x * z, this.x * y - this.y * x);
	}

	public float dot(Vector3f v){
		return dot(v.x, v.y, v.z);
	}
	
	public float dot(float x, float y, float z){
		return this.x * x + this.y * y + this.z * z;
	}
	
	public Vector3f nor () {
		final float len2 = len2();
		if (len2 == 0f || len2 == 1f) return this;
		return scl(1f / (float)Math.sqrt(len2));
	}

	public Vector3f scl (float scalar) {
		return set(this.x * scalar, this.y * scalar, this.z * scalar);
	}

	public Vector3f scl (final Vector3f other) {
		return set(x * other.x, y * other.y, z * other.z);
	}
	
	public float dst2(Vector3f v){
		return dst2(v.x,v.y,v.z);
	}
	
	public float dst2(float x, float y, float z){
		return (this.x-x)*(this.x-x) + (this.y-y)*(this.y-y) + (this.z-z)*(this.z-z);
	}
	
	public static float dst2(Vector3f v1, Vector3f v2){
		return v1.dst2(v2);
	}
	
	public float len () {
		return (float)Math.sqrt(len2());
	}
	public float len(float x, float y, float z){
		return (float)Math.sqrt(len2(x, y, z));
	}

	public float len2(){
		return x*x + y*y +z*z;
	}
	
	public float len2(float x, float y, float z){
		return x*x + y*y +z*z;
	}
	
	public Vector3f prj (final float[] mat) {
		final float l_w = 1f / (x * mat[Matrix4f.M30] + y * mat[Matrix4f.M31] + z * mat[Matrix4f.M32] + mat[Matrix4f.M33]);
		return this.set((x * mat[Matrix4f.M00] + y * mat[Matrix4f.M01] + z * mat[Matrix4f.M02] + mat[Matrix4f.M03]) * l_w, (x
						* mat[Matrix4f.M10] + y * mat[Matrix4f.M11] + z * mat[Matrix4f.M12] + mat[Matrix4f.M13])
						* l_w, (x * mat[Matrix4f.M20] + y * mat[Matrix4f.M21] + z * mat[Matrix4f.M22] + mat[Matrix4f.M23]) * l_w);
	}
	
	public Vector3f rotate(float w, float x, float y, float z){
		float[] tmpMat = new float[16];
		Matrix4f.setIdentityM(tmpMat,0);
		Matrix4f.setRotateM(tmpMat,0,w,x,y,z);
		return mul(tmpMat);
	}
	
}
