package bogo.kaayo.math;

public class Plane{
	public Vector3f A = new Vector3f();
	public Vector3f B = new Vector3f();
	public Vector3f C = new Vector3f();

	public enum PlaneSide {
		OnPlane, Back, Front
		}

	public final Vector3f normal = new Vector3f();
	public float d = 0;

	public Plane(Vector3f point1, Vector3f point2, Vector3f point3){
		A.set(point1);
		B.set(point2);
		C.set(point3);
		normal.set(point1).sub(point2).crs(point2.x-point3.x, point2.y-point3.y, point2.z-point3.z).nor();
		d = -point1.dot(normal);
	}

	public PlaneSide testPoint (Vector3f point) {
		float dist = normal.dot(point) + d;

		if (dist == 0)
			return PlaneSide.OnPlane;
		else if (dist < 0)
			return PlaneSide.Back;
		else
			return PlaneSide.Front;
	}

	public PlaneSide testPoint (float x, float y, float z) {
		float dist = normal.dot(x, y, z) + d;

		if (dist == 0)
			return PlaneSide.OnPlane;
		else if (dist < 0)
			return PlaneSide.Back;
		else
			return PlaneSide.Front;
	}

}
