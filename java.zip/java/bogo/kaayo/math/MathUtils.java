package bogo.kaayo.math;

public class MathUtils{
	
	public static float max(float p1, float p2){
		return p1>p2?p1:p2;
	}
	
	public static float min(float p1, float p2){
		return p1<p2?p1:p2;
	}
	
}
