package bogo.kaayo.math;

public class Intersector{
	
	public static boolean intersectRayPlane (PickRay ray, Plane plane, Vector3f intersection) {
		Vector3f tmp = new Vector3f();
		float denom = ray.direction.dot(plane.normal);
		if (denom != 0) {
			float t = -(ray.origin.dot(plane.normal) + plane.d) / denom;
			if (t < 0) return false;

			if (intersection != null) intersection.set(ray.origin).add(tmp.set(ray.direction).scl(t));
			return true;
		} else if (plane.testPoint(ray.origin) == Plane.PlaneSide.OnPlane) {
			if (intersection != null) intersection.set(ray.origin);
			return true;
		} else
			return false;
	}
	
	static Vector3f v0 = new Vector3f();
	public static boolean intersectSegmentPlane (Vector3f start, Vector3f end, Plane plane, Vector3f intersection) {
		Vector3f dir = v0.set(end).sub(start);
		float denom = dir.dot(plane.normal);
		if (denom == 0f) return false;
		float t = -(start.dot(plane.normal) + plane.d) / denom;
		if (t < 0 || t > 1) return false;

		if(intersection != null)
			intersection.set(start).add(dir.scl(t));
		return true;
	}
	
}
