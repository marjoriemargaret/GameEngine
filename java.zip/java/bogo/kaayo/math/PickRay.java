package bogo.kaayo.math;

public class PickRay{
	public Vector3f origin = new Vector3f();
	public Vector3f direction = new Vector3f();
	
	public PickRay set(Vector3f origin, Vector3f direction){
		this.origin.set(origin);
		this.direction.set(direction);
		return this;
	}
	
	public PickRay copy(){
		return new PickRay().set(origin,direction);
	}
	
	public Vector3f getEndPoint(float distance){
		return new Vector3f(direction).scl(distance).add(origin);
	}
	
}
