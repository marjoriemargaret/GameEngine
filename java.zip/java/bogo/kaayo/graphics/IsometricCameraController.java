package bogo.kaayo.graphics;

import bogo.kaayo.input.InputListener;
import bogo.kaayo.utils.Queuevii;
import bogo.kaayo.math.Vector3f;
import bogo.kaayo.input.InputListener.*;
import bogo.kaayo.Rb;
import bogo.kaayo.graphics.shaders.Shader;
import java.util.ArrayList;
import bogo.kaayo.math.PickRay;
import bogo.kaayo.RbException;

public class IsometricCameraController implements InputListener{
	private Camera cam;
	private Queuevii<Vector3f> touchA = new Queuevii<Vector3f>(5);
	private Queuevii<Vector3f> touchB = new Queuevii<Vector3f>(5);
	private Vector3f smoothing = new Vector3f();
	private state camState = state.TRANSLATE;
	public int transition = 10;
	
	public IsometricCameraController(Camera c){
		cam = c;
		cam.translate(0,5,3);
		cam.lookAt(0,0,0);
		Rb.input.addInputProcessor(this);
		Rb.input.setTouchDelay(200);
	}
	
	public void control(Camera c){
		cam = c;
		switch(camState){
			case TRANSLATE:
				cam.translate(smoothing.x * Rb.graphics.deltaTime(),0,0);
				cam.translate(0,0,smoothing.y * Rb.graphics.deltaTime());
				break;
			case ZOOM:
				cam.translate(0,smoothing.x * Rb.graphics.deltaTime(),smoothing.y * Rb.graphics.deltaTime());
				break;
		}
		if(smoothing.x>0){
			smoothing.x -= 0.5f;
		}
		if(smoothing.x<0){
			smoothing.x += 0.5f;
		}
		if(smoothing.y>0){
			smoothing.y -= 0.5f;
		}
		if(smoothing.y<0){
			smoothing.y += 0.5f;
		}
	}
	
	private Vector3f ray = new Vector3f();
	@Override
	public void justTouch(InputListener.Event e){
		Vector3f clip = new Vector3f();
		float cx = 2.0f*e.getX(0)/Rb.graphics.width()-1.0f;
		float cy = -1.0f;
		float cz = 2.0f*e.getY(0)/Rb.graphics.height()-2.0f;
		clip.set(cx,cy,cz);
		ray.set(clip).nor();
	}
	
	@Override
	public void touchDown(InputListener.Event e){
		float dy = transition + cam.position.y;
		if(e.getPointerCount()==1){
			camState = state.TRANSLATE;
			touchA.enqueue(new Vector3f(e.getX(0),e.getY(0),0));
			Vector3f dir = new Vector3f(touchA.getTail()).sub(touchA.getHead()).nor();
			smoothing.set((int)(dir.x*dy),(int)(dir.y*dy),0);
		}else if(e.getPointerCount()==2){
			camState = state.ZOOM;
			touchA.enqueue(new Vector3f(e.getX(0),e.getY(0),0));
			touchB.enqueue(new Vector3f(e.getX(1),e.getY(1),0));
			float dstHead = new Vector3f(touchA.getHead()).dst2(touchB.getHead());
			float dstTail = new Vector3f(touchA.getTail()).dst2(touchB.getTail());
			if(dstHead>dstTail){
				smoothing.set(-transition,-transition,0);
			}if(dstHead<dstTail){
				smoothing.set(transition,transition,0);
			}
		}
	}

	@Override
	public void touchUp(InputListener.Event e){
		touchA.clear();
		if(e.getPointerCount()==2) touchB.clear();
	}
	
	private enum state{
		TRANSLATE,
		ZOOM
	}
	
}
