package bogo.kaayo.graphics.shaders;

import bogo.kaayo.files.FileHandle;
import java.io.BufferedReader;
import java.io.IOException;
import bogo.kaayo.RbException;
import bogo.kaayo.Rb;
import java.util.ArrayList;
import java.nio.Buffer;
import bogo.kaayo.math.Vector3f;

public class Shader{
	private int programId = 0;
	public Location location = new Location();
	private ArrayList<Integer> current = new ArrayList<>();
	
	public Shader(FileHandle vertex, FileHandle fragment){
		BufferedReader vbr = vertex.getBuffer();
		BufferedReader fbr = fragment.getBuffer();
		String vertexSource = "";
		String fragmentSource = "";
		String line = null;
		try{
			while ((line = vbr.readLine()) != null){
				vertexSource += line+"\n";
			}
			while ((line = fbr.readLine()) != null){
				fragmentSource += line+"\n";
			}
		}catch (IOException e){
			throw new RbException(e);
		}
		loadAll(vertexSource,fragmentSource);
	}
	
	public Shader(String vertexSource, String fragmentSource){
		loadAll(vertexSource,fragmentSource);
	}
	
	public void loadAll(String vertexSource, String fragmentSource){
		int vertexId = loadShader(Rb.GL20.GL_VERTEX_SHADER,vertexSource);
		int fragmentId = loadShader(Rb.GL20.GL_FRAGMENT_SHADER,fragmentSource);

		programId = Rb.GL20.glCreateProgram();
		Rb.GL20.glAttachShader(programId,vertexId);
		Rb.GL20.glAttachShader(programId,fragmentId);
		Rb.GL20.glLinkProgram(programId);
		Rb.GL20.glValidateProgram(programId);
	}
	
	public int programId(){
		return programId;
	}

	public void start(){
		Rb.GL20.glUseProgram(programId());
		Rb.GL20.glFrontFace(Rb.GL20.GL_CCW);
		current.clear();
	}
	
	public void loadAttribute(String name, int count, int mode, int stride,  Buffer data){
		int i = location.attributes.get(name);
		current.add(i);
		Rb.GL20.glVertexAttribPointer(i,count,mode,false,stride,data);
		Rb.GL20.glEnableVertexAttribArray(i);
	}
	
	public void loadUniformMatrix4(String name, float[] mat){
		int i = location.uniforms.get(name);
		Rb.GL20.glUniformMatrix4fv(i,1,false,mat,0);
	}
	
	public void loadUniformVector3(String name, Vector3f vector){
		int i = location.uniforms.get(name);
		Rb.GL20.glUniform3f(i,vector.x,vector.y,vector.z);
	}
	
	public void loadUniformInt(String name, int p){
		int i = location.uniforms.get(name);
		Rb.GL20.glUniform1i(i,p);
	}

	public void stop(){
		for(int i : current){
			Rb.GL20.glDisableVertexAttribArray(i);
		}
		Rb.GL20.glUseProgram(0);
	}

	public int getAttribute(String name){
		return Rb.GL20.glGetAttribLocation(programId(),name);
	}

	public int getUniform(String name){
		return Rb.GL20.glGetUniformLocation(programId(),name);
	}

	/*public void clear(){
	 Rb.GLES20.glDetachShader(programId,vertexId);
	 Rb.GLES20.glDetachShader(programId,fragmentId);
	 Rb.GLES20.glDeleteShader(vertexId);
	 Rb.GLES20.glDeleteShader(fragmentId);
	 Rb.GLES20.glDeleteProgram(programId);
	 }*/

	private static int loadShader(int shaderType, String shaderSource){
		int id = Rb.GL20.glCreateShader(shaderType);
		if(id==0){
			System.out.println("unable to create shader");
			return 0;
		}
		Rb.GL20.glShaderSource(id,shaderSource);
		Rb.GL20.glCompileShader(id);
		int compile[] = new int[1];
		Rb.GL20.glGetShaderiv(id,Rb.GL20.GL_COMPILE_STATUS,compile,0);
		if(compile[0]==Rb.GL20.GL_FALSE){
			System.out.println("could not compile shader");
			System.out.println(Rb.GL20.glGetShaderInfoLog(id));
			Rb.GL20.glDeleteShader(id);
			return 0;
		}
		return id;
	}
	
}
