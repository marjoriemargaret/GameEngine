package bogo.kaayo.graphics.shaders;

import java.util.HashMap;

public class Location{
	
	public HashMap<String,Integer> attributes = new HashMap<>();
	
	public HashMap<String,Integer> uniforms = new HashMap<>();
	
}
