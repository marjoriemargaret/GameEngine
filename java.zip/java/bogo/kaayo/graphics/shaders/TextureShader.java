package bogo.kaayo.graphics.shaders;

import bogo.kaayo.files.FileHandle;
import bogo.kaayo.Rb;
import bogo.kaayo.RbException;

public class TextureShader extends Shader{
	private int textureId;
	
	public TextureShader(String texture){
		super(Rb.files.obb("opengl 2.0/shaders/Texture.vert.glsl"),
		Rb.files.obb("opengl 2.0/shaders/Texture.frag.glsl"));
		
		int[] textures = new int[1];
		Rb.GL20.glGenTextures(1, textures, 0);
		textureId = textures[0];
		Rb.GL20.glBindTexture(Rb.GL20.GL_TEXTURE_2D, textureId);
		Rb.GL20.glGenerateMipmap(Rb.GL20.GL_TEXTURE_2D);
		Rb.GL20.glTexParameteri(Rb.GL20.GL_TEXTURE_2D,Rb.GL20.GL_TEXTURE_MIN_FILTER,Rb.GL20.GL_LINEAR_MIPMAP_LINEAR);
		Rb.GL20.glTexParameterf(Rb.GL20.GL_TEXTURE_2D,Rb.GL20.GL_TEXTURE_MIN_FILTER,Rb.GL20.GL_NEAREST);
		//Rb.GL20.glTexParameterf(Rb.GL20.GL_TEXTURE_2D,Rb.GL20.GL_TEXTURE_MAG_FILTER,Rb.GL20.GL_LINEAR);
		/*Rb.GL20.glTexParameteri(Rb.GL20.GL_TEXTURE_2D,Rb.GL20.GL_TEXTURE_WRAP_S,Rb.GL20.GL_REPEAT);
		Rb.GL20.glTexParameteri(Rb.GL20.GL_TEXTURE_2D,Rb.GL20.GL_TEXTURE_WRAP_T,Rb.GL20.GL_REPEAT);*/
		try{
			Rb.GLU.load(texture);
		}catch (Exception e){
			throw new RbException(e);
		}
		
		location.attributes.put("textures",getAttribute("textures"));
		location.attributes.put("vertices",getAttribute("vertices"));
		location.attributes.put("normals",getAttribute("normals"));
		location.uniforms.put("projection",getUniform("projection"));
		location.uniforms.put("transformation",getUniform("transformation"));
		location.uniforms.put("view",getUniform("view"));
		location.uniforms.put("lightPos",getUniform("lightPos"));
	}
	
	public void start(){
		super.start();
		Rb.GL20.glActiveTexture(Rb.GL20.GL_TEXTURE0);
		Rb.GL20.glBindTexture(Rb.GL20.GL_TEXTURE_2D, textureId);
	}
	
}
