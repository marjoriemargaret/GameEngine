package bogo.kaayo.graphics.shaders;

import bogo.kaayo.files.FileHandle;
import bogo.kaayo.Rb;
import bogo.kaayo.RbException;
import org.json.JSONArray;
import bogo.kaayo.utils.JSON;

public class BlendShader extends Shader{
	private int[] textureId;

	public BlendShader(FileHandle jsonfile){
		super(Rb.files.obb("opengl 2.0/shaders/Blend.vert.glsl"),
			  Rb.files.obb("opengl 2.0/shaders/Blend.frag.glsl"));

		JSONArray json = JSON.toArray(jsonfile);
		textureId = new int[5];
		Rb.GL20.glGenTextures(5,textureId,0);
		for (int i=0; i < textureId.length; i++){
			Rb.GL20.glBindTexture(Rb.GL20.GL_TEXTURE_2D, textureId[i]);
			Rb.GL20.glTexParameterf(Rb.GL20.GL_TEXTURE_2D,Rb.GL20.GL_TEXTURE_MAG_FILTER,Rb.GL20.GL_LINEAR);
			Rb.GL20.glTexParameterf(Rb.GL20.GL_TEXTURE_2D,Rb.GL20.GL_TEXTURE_MIN_FILTER,Rb.GL20.GL_NEAREST);
			Rb.GL20.glTexParameteri(Rb.GL20.GL_TEXTURE_2D,Rb.GL20.GL_TEXTURE_WRAP_S,Rb.GL20.GL_REPEAT);
			Rb.GL20.glTexParameteri(Rb.GL20.GL_TEXTURE_2D,Rb.GL20.GL_TEXTURE_WRAP_T,Rb.GL20.GL_REPEAT);
			try{
				Rb.GLU.load(json.getString(i));
			}catch (Exception e){
				throw new RbException(e);
			}
		}

		location.attributes.put("textures",getAttribute("textures"));
		location.attributes.put("vertices",getAttribute("vertices"));
		location.attributes.put("normals",getAttribute("normals"));
		location.uniforms.put("projection",getUniform("projection"));
		location.uniforms.put("transformation",getUniform("transformation"));
		location.uniforms.put("view",getUniform("view"));
		location.uniforms.put("lightPos",getUniform("lightPos"));
		
		location.uniforms.put("background",getUniform("background"));
		location.uniforms.put("rTex",getUniform("rTex"));
		location.uniforms.put("gTex",getUniform("gTex"));
		location.uniforms.put("bTex",getUniform("bTex"));
		location.uniforms.put("blendMap",getUniform("blendMap"));
		
	}

	public void start(){
		super.start();
		bindTextures();
		loadUniformInt("background",0);
		loadUniformInt("rTex",1);
		loadUniformInt("gTex",2);
		loadUniformInt("bTex",3);
		loadUniformInt("blendMap",4);
	}
	
	void bindTextures(){
		Rb.GL20.glActiveTexture(Rb.GL20.GL_TEXTURE0);
		Rb.GL20.glBindTexture(Rb.GL20.GL_TEXTURE_2D, textureId[0]);
		Rb.GL20.glActiveTexture(Rb.GL20.GL_TEXTURE1);
		Rb.GL20.glBindTexture(Rb.GL20.GL_TEXTURE_2D, textureId[1]);
		Rb.GL20.glActiveTexture(Rb.GL20.GL_TEXTURE2);
		Rb.GL20.glBindTexture(Rb.GL20.GL_TEXTURE_2D, textureId[2]);
		Rb.GL20.glActiveTexture(Rb.GL20.GL_TEXTURE3);
		Rb.GL20.glBindTexture(Rb.GL20.GL_TEXTURE_2D, textureId[3]);
		Rb.GL20.glActiveTexture(Rb.GL20.GL_TEXTURE4);
		Rb.GL20.glBindTexture(Rb.GL20.GL_TEXTURE_2D, textureId[4]);
	}

}
