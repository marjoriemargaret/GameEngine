package bogo.kaayo.graphics.shaders;

import bogo.kaayo.files.FileHandle;
import bogo.kaayo.Rb;
import bogo.kaayo.RbException;

import bogo.kaayo.math.Vector3f;
import bogo.kaayo.graphics.Mesh;

public class MaterialShader extends Shader{
	
	public MaterialShader(){
		super(Rb.files.obb("opengl 2.0/shaders/Material.vert.glsl"),
			  Rb.files.obb("opengl 2.0/shaders/Material.frag.glsl"));
			  
		location.attributes.put("textures",getAttribute("textures"));
		location.attributes.put("vertices",getAttribute("vertices"));
		location.attributes.put("normals",getAttribute("normals"));
		location.attributes.put("color",getAttribute("color"));
		location.uniforms.put("projection",getUniform("projection"));
		location.uniforms.put("transformation",getUniform("transformation"));
		location.uniforms.put("view",getUniform("view"));
		location.uniforms.put("lightPos",getUniform("lightPos"));
	}

}
