package bogo.kaayo.graphics.r2d;

import bogo.kaayo.Rb;
import bogo.kaayo.RbException;
import bogo.kaayo.files.FileHandle;
import bogo.kaayo.graphics.Mesh;
import java.util.HashMap;
import org.json.JSONArray;
import org.json.JSONObject;
import bogo.kaayo.math.MathUtils;
import bogo.kaayo.utils.JSON;
import org.json.JSONException;

public class BitmapFont{
	private HashMap<Integer,CharacterData> characters = new HashMap<>();
	private FileHandle font;
	private JSONArray jsonArray;
	private Mesh mesh;
	private int texture;

	public BitmapFont(){
		this(Rb.files.obb("arial-15.json"));
	}

	public BitmapFont(FileHandle file){
		font = file;
		jsonArray = JSON.toArray(file);
		try{
			JSONObject info = jsonArray.getJSONObject(0);
			texture = loadTexture(font.getFile().getParent()+"/"+info.get("file"));
			int count = info.get("count");
			for(int i=1; i<count; i++){
				JSONObject jobj = jsonArray.getJSONObject(i);
				CharacterData data = new CharacterData();
				data.x = jobj.get("x");
				data.y = jobj.get("y");
				data.width = jobj.get("width");
				data.height = jobj.get("height");
				data.xoffset = jobj.get("xoffset");
				data.yoffset = jobj.get("yoffset");
				data.xadvance = jobj.get("xadvance");
				characters.put(jobj.getInt("id"),data);
			}
		}catch (JSONException e){
			throw new RbException(e);
		}
	}

	private android.opengl.Matrix Matrix4f;
	public void draw(Batch batch, float x, float y, float scale, String... sequence){
		float aspect = (float)Rb.graphics.width()/(float)Rb.graphics.height();
		Matrix4f.orthoM(batch.projection,0,-aspect,aspect,-1,1,1,100);
		
		mesh = new Mesh();
		int strLength = 0;
		for(String str : sequence){
			strLength += str.length();
		}
		mesh.vertices = new float[strLength*3*4];
		mesh.textures = new float[strLength*2*4];
		mesh.indices = new short[strLength*2*3];
		int index = 0;
		float ycursor = 0;
		for(String str : sequence){
			char[] ch = str.toCharArray();
			float xcursor = 0;
			float tmpycursor = 0;
			for(int id : ch){
				CharacterData data = characters.get(id);
				
				float yc = Rb.GLU.clip(ycursor,Rb.graphics.height())*scale;
				float tx = Rb.GLU.clip(x,Rb.graphics.width())-aspect;
				float ty = 1-Rb.GLU.clip(y,Rb.graphics.height())-yc;
				float pw = Rb.GLU.clip(data.width,Rb.graphics.width())*aspect*scale;
				float ph = Rb.GLU.clip(data.height,Rb.graphics.height())*1*scale;
				float pyo = Rb.GLU.clip(data.yoffset,Rb.graphics.height())*1*scale;
				float pxo = Rb.GLU.clip(data.xoffset,Rb.graphics.width())*aspect*scale;
				
				mesh.vertices[index*12] = tx+pxo+xcursor;
				mesh.vertices[index*12+1] = ty-pyo;
				mesh.vertices[index*12+2] = -2;    //left-top
				
				mesh.vertices[index*12+3] = tx+pw+pxo+xcursor;
				mesh.vertices[index*12+4] = ty-pyo;
				mesh.vertices[index*12+5] = -2; //right-top
				
				mesh.vertices[index*12+6] = tx+pw+pxo+xcursor;
				mesh.vertices[index*12+7] = ty-ph-pyo;
				mesh.vertices[index*12+8] = -2;    //right-bottom
				
				mesh.vertices[index*12+9] = tx+pxo+xcursor;
				mesh.vertices[index*12+10] = ty-ph-pyo;
				mesh.vertices[index*12+11] = -2;       //left-bottom
				
				mesh.textures[index*8] = (float)data.x/256;
				mesh.textures[index*8+1] = (float)data.y/128;
				
				mesh.textures[index*8+2] = ((float)data.x+(float)data.width)/256;
				mesh.textures[index*8+3] = (float)data.y/128;
				
				mesh.textures[index*8+4] = ((float)data.x+(float)data.width)/256;
				mesh.textures[index*8+5] = ((float)data.y+(float)data.height)/128;
				
				mesh.textures[index*8+6] = (float)data.x/256;
				mesh.textures[index*8+7] = ((float)data.y+(float)data.height)/128;
				
				mesh.indices[index*6] = (short)(index*4);
				mesh.indices[index*6+1] = (short)(index*4+1);
				mesh.indices[index*6+2] = (short)(index*4+2);
				
				mesh.indices[index*6+3] = (short)(index*4);
				mesh.indices[index*6+4] = (short)(index*4+2);
				mesh.indices[index*6+5] = (short)(index*4+3);
				
				index++;
				xcursor += Rb.GLU.clip(data.xadvance,Rb.graphics.width())*aspect*scale+pxo;
				tmpycursor = MathUtils.max(tmpycursor,data.height+data.yoffset);
			}
			ycursor += tmpycursor;
		}
		mesh.bindVertices();
		mesh.bindTextures();
		mesh.bindIndices();
		
		Rb.GL20.glActiveTexture(Rb.GL20.GL_TEXTURE0);
		Rb.GL20.glBindTexture(Rb.GL20.GL_TEXTURE_2D, texture);
		
		batch.shader.loadAttribute("vertices",3,Rb.GL20.GL_FLOAT,Rb.D3D*Rb.FLOAT_SIZE_BYTES,mesh.vertexBuffer);
		batch.shader.loadAttribute("textureCoord",2,Rb.GL20.GL_FLOAT,Rb.D2D*Rb.FLOAT_SIZE_BYTES,mesh.textureBuffer);
		batch.shader.loadUniformMatrix4("projection",batch.projection);

		Rb.GL20.glDrawElements(Rb.GL20.GL_TRIANGLES,mesh.indices.length,Rb.GL20.GL_UNSIGNED_SHORT,mesh.indexBuffer);
		
		mesh.unbindAll();
	}

	public void draw(Batch batch, float x, float y, String... sequence){
		draw(batch,x,y,1,sequence);
	}

	private int loadTexture(String path){
		int[] textures = new int[1];
		Rb.GL20.glGenTextures(1, textures, 0);
		int texture = textures[0];
		Rb.GL20.glBindTexture(Rb.GL20.GL_TEXTURE_2D, texture);
		Rb.GL20.glTexParameterf(Rb.GL20.GL_TEXTURE_2D,Rb.GL20.GL_TEXTURE_MIN_FILTER,Rb.GL20.GL_NEAREST);
		Rb.GL20.glTexParameterf(Rb.GL20.GL_TEXTURE_2D,Rb.GL20.GL_TEXTURE_MAG_FILTER,Rb.GL20.GL_LINEAR);
		Rb.GL20.glTexParameteri(Rb.GL20.GL_TEXTURE_2D,Rb.GL20.GL_TEXTURE_WRAP_S,Rb.GL20.GL_REPEAT);
		Rb.GL20.glTexParameteri(Rb.GL20.GL_TEXTURE_2D,Rb.GL20.GL_TEXTURE_WRAP_T,Rb.GL20.GL_REPEAT);
		try{
			Rb.GLU.load(path);
		}catch (Exception e){
			throw new RbException(e);
		}
		return texture;
	}

	public class CharacterData{
		int x;
		int y;
		int width;
		int height;
		int xoffset;
		int yoffset;
		int xadvance;
	}

}
