package bogo.kaayo.graphics.r2d.ui;

import bogo.kaayo.input.InputListener;
import bogo.kaayo.Rb;
import bogo.kaayo.input.InputListener.*;
import bogo.kaayo.graphics.r2d.*;
import bogo.kaayo.math.*;

public class Joystick{
	private Style style;
	private boolean isTouched;
	private Vector3f knobPosition = new Vector3f();
	public Vector3f knobPercent = new Vector3f();
	private Circle knobBounds = new Circle();
	private int P_INDEX = 0;
	
	public Joystick(final Style joysticStyle, int index){
		this.style = joysticStyle;
		knobPosition.set(style.padRadius,style.padRadius,0);
		knobBounds.set(style.position.x+style.padRadius,style.position.y+style.padRadius,style.padRadius);
		P_INDEX = index;
		
		Rb.input.addInputProcessor(new InputListener(){
			@Override
			public void touchUp(InputListener.Event e){
				float y = Rb.graphics.height()-e.getY(P_INDEX);
				calculate(e.getX(P_INDEX),y,true);
				isTouched = false;
			}
			
			@Override
			public void touchDown(InputListener.Event e){
				float y = Rb.graphics.height()-e.getY(P_INDEX);
				calculate(e.getX(P_INDEX),y,false);
			}
			
			@Override
			public void justTouch(InputListener.Event e){
				float y = Rb.graphics.height()-e.getY(P_INDEX);
				if(knobBounds.contains(e.getX(P_INDEX),y,style.knobRadius)){
					isTouched = true;
					calculate(e.getX(P_INDEX),y,false);
				}
			}
		});
	}
	
	void calculate(float x, float y, boolean touchUp){
		knobPosition.set(style.padRadius,style.padRadius,0);
		knobPercent.set(0,0,0);
		if(!touchUp && isTouched){
			knobPercent.set((x - knobBounds.x) / knobBounds.radius, (y - knobBounds.y) / knobBounds.radius,0);
			float length = knobPercent.len();
			if (length > 1) knobPercent.scl(1 / length);
			if (knobBounds.contains(x,y,style.knobRadius)) {
				knobPosition.set(x-style.position.x, y-style.position.y,0);
			} else {
				knobPosition.set(knobPercent).nor().scl(knobBounds.radius-style.knobRadius).add(knobBounds.x, knobBounds.y,0).sub(style.position);
			}
		}
	}
	
	public void draw(Batch batch){
		float x = style.position.x;
		float y = style.position.y;
		float r2 = style.padRadius*2;
		style.pad.draw(batch,x,y,r2,r2);
		x += knobPosition.x - style.knobRadius;
		y += knobPosition.y - style.knobRadius;
		r2 = style.knobRadius*2;
		style.knob.draw(batch,x,y,r2,r2);
	}
	
	public boolean isTouched(){
		return isTouched;
	}
	
	public static class Style{
		public Texture pad;
		public Texture knob;
		public Vector3f position;
		public float padRadius;
		public float knobRadius;
		
		public Style(){
			
		}
		
		public Style(Texture pad, Texture knob, Vector3f position, float padRadius, float knobRadius){
			this.pad = pad;
			this.knob = knob;
			this.position = position;
			this.padRadius = padRadius;
			this.knobRadius = knobRadius;
		}
		
	}
	
	class Circle{
		float x;
		float y;
		float radius;
		
		public void set(float x, float y, float radius){
			this.x = x;
			this.y = y;
			this.radius = radius;
		}
		
		public boolean contains (float x, float y) {
			return contains(x,y,0);
		}
		
		public boolean contains (float x, float y, float rOffset){
			x = this.x - x;
			y = this.y - y;
			return x * x + y * y <= (radius-rOffset) * (radius-rOffset);
		}
		
	}
	
}
