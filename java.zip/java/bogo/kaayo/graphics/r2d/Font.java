package bogo.kaayo.graphics.r2d;

import bogo.kaayo.files.FileHandle;
import bogo.kaayo.Rb;
import bogo.kaayo.utils.JSON;
import org.json.JSONArray;
import java.util.HashMap;
import org.json.JSONObject;
import org.json.JSONException;
import bogo.kaayo.RbException;
import bogo.kaayo.math.Vector3f;
import java.util.*;

public class Font{
	JSONArray json;
	HashMap<Integer,Character> characters = new HashMap<>();
	
	public Font(){
		this(Rb.files.obb("arial-15.json"));
	}
	
	public Font(FileHandle font){
		json = JSON.toArray(font);
		try{
			JSONObject info = json.getJSONObject(0);
			//texture = loadTexture(font.getFile().getParent()+"/"+info.get("file"));
			int count = info.get("count");
			for(int i=1; i<count; i++){
				JSONObject jobj = json.getJSONObject(i);
				Character data = new Character();
				float x = jobj.get("x");
				float y = jobj.get("y");
				float width = jobj.get("width");
				float height = jobj.get("height");
				float xoffset = jobj.get("xoffset");
				float yoffset = jobj.get("yoffset");
				float xadvance = jobj.get("xadvance");
				
				//float tx = Rb.GLU.clip(x,Rb.graphics.width())-aspect;
				//float ty = 1-Rb.GLU.clip(y,Rb.graphics.height())-yc;
				//float pw = Rb.GLU.clip(data.width,Rb.graphics.width())*aspect*scale;
				//float ph = Rb.GLU.clip(data.height,Rb.graphics.height())*1*scale;
				
				characters.put(jobj.getInt("id"),data);
			}
		}catch (JSONException e){
			throw new RbException(e);
		}
	}
	
	private class Character{
		public ArrayList<Vector3f> vertices = new ArrayList<>();
		public ArrayList<Vector3f> textures = new ArrayList<>();
		public float xOffset;
		public float yOffset;
		public float xAdvance;
		
		public float[] getVertices(float xOffset, float yOffset){
			float[] tmp = new float[vertices.size()*3];
			for(int i=0; i<vertices.size(); i++){
				Vector3f v = vertices.get(i);
				tmp[i*3] = v.x+xOffset;
				tmp[i*3+1] = v.y+yOffset;
				tmp[i*3+2] = v.z;
			}
			return tmp;
		}
	}
	
}
