package bogo.kaayo.graphics.r2d;

import bogo.kaayo.files.FileHandle;
import bogo.kaayo.graphics.shaders.Shader;
import bogo.kaayo.graphics.Mesh;
import bogo.kaayo.Rb;
import bogo.kaayo.RbException;
import bogo.kaayo.graphics.Camera;
import bogo.kaayo.math.Matrix4f;
import bogo.kaayo.math.Vector3f;

public class Texture{
	private Mesh mesh;
	private int textureId;
	private float[] projection = new float[16];
	
	public Texture(FileHandle texture){
		Matrix4f.setIdentityM(projection,0);
		mesh = new Mesh();
		
		int[] textures = new int[1];
		Rb.GL20.glGenTextures(1, textures, 0);
		textureId = textures[0];
		Rb.GL20.glBindTexture(Rb.GL20.GL_TEXTURE_2D, textureId);
		Rb.GL20.glTexParameterf(Rb.GL20.GL_TEXTURE_2D,Rb.GL20.GL_TEXTURE_MIN_FILTER,Rb.GL20.GL_NEAREST);
		Rb.GL20.glTexParameterf(Rb.GL20.GL_TEXTURE_2D,Rb.GL20.GL_TEXTURE_MAG_FILTER,Rb.GL20.GL_LINEAR);
		Rb.GL20.glTexParameteri(Rb.GL20.GL_TEXTURE_2D,Rb.GL20.GL_TEXTURE_WRAP_S,Rb.GL20.GL_REPEAT);
		Rb.GL20.glTexParameteri(Rb.GL20.GL_TEXTURE_2D,Rb.GL20.GL_TEXTURE_WRAP_T,Rb.GL20.GL_REPEAT);
		try{
			Rb.GLU.load(texture.getFile().getPath());
		}catch (Exception e){
			throw new RbException(e);
		}
		mesh.textures = new float[]{
			0, 1,
			1, 1,
			1, 0,
			0, 0
		};
		mesh.indices = new short[]{
			0, 1, 2,
			0, 2, 3
		};
		mesh.bindTextures();
		mesh.bindIndices();
	}
	
	private void bind(float px, float py, float pw, float ph){
		mesh.vertices = new float[]{
			px, py, -2,          //left-top
			px+pw, py, -2,       //right-top
			px+pw, py+ph, -2,    //right-bottom
			px, py+ph, -2,       //left-bottom
		};
		mesh.bindVertices();
	}
	
	public void draw(Batch batch, float x, float y, float width, float height){
		Matrix4f.orthoM(projection,0,-1,1,-1,1,1,100);
		
		Rb.GL20.glActiveTexture(Rb.GL20.GL_TEXTURE0);
		Rb.GL20.glBindTexture(Rb.GL20.GL_TEXTURE_2D, textureId);
		
		Vector3f deviceCoord = Rb.GLU.getNormalizedDeviceCoords(x,y);
		float tx = deviceCoord.x;
		float ty = deviceCoord.y;
		deviceCoord = Rb.GLU.getNormalizedDeviceCoords(width,height);
		float pw = deviceCoord.x+1;
		float ph = deviceCoord.y+1;
		bind(tx,ty,pw,ph);
		
		batch.shader.loadAttribute("vertices",3,Rb.GL20.GL_FLOAT,Rb.D3D*Rb.FLOAT_SIZE_BYTES,mesh.vertexBuffer);
		batch.shader.loadAttribute("textureCoord",2,Rb.GL20.GL_FLOAT,Rb.D2D*Rb.FLOAT_SIZE_BYTES,mesh.textureBuffer);
		batch.shader.loadUniformMatrix4("projection",projection);
		
		Rb.GL20.glDrawElements(Rb.GL20.GL_TRIANGLES,mesh.indices.length,Rb.GL20.GL_UNSIGNED_SHORT,mesh.indexBuffer);
		
		//mesh.unbindAll();
	}
	
}
