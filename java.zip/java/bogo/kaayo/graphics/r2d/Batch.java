package bogo.kaayo.graphics.r2d;

import bogo.kaayo.*;
import bogo.kaayo.files.*;
import bogo.kaayo.graphics.model.*;
import bogo.kaayo.graphics.model.loader.*;
import bogo.kaayo.graphics.shaders.*;

public class Batch{
	public Shader shader;
	private android.opengl.Matrix Matrix4f;
	public float[] projection = new float[16];

	public Batch(){
		Matrix4f.setIdentityM(projection,0);
		shader = new Shader(vSource,pSource);
		
		shader.location.attributes.put("textureCoord",shader.getAttribute("textureCoord"));
		shader.location.attributes.put("vertices",shader.getAttribute("vertices"));
		shader.location.uniforms.put("projection",shader.getUniform("projection"));
	}
	
	public void begin(){
		Rb.GL20.glEnable(Rb.GL20.GL_BLEND);
		Rb.GL20.glBlendFunc(Rb.GL20.GL_SRC_ALPHA,Rb.GL20.GL_ONE_MINUS_SRC_ALPHA);
		//Rb.GL20.glEnable(Rb.GL20.GL_CULL_FACE);
		//Rb.GL20.glCullFace(Rb.GL20.GL_BACK);
		shader.start();
	}
	
	public void end(){
		shader.stop();
		Rb.GL20.glDisable(Rb.GL20.GL_BLEND);
		//Rb.GL20.glDisable(Rb.GL20.GL_CULL_FACE);
	}

	private final String vSource =
	"attribute vec4 vertices;\n"+
	"attribute vec2 textureCoord;\n"+
	"varying vec2 texture;\n"+
	"uniform mat4 projection;\n"+
	"void main(){\n"+
	"gl_Position = projection * vertices;\n"+
	"texture = textureCoord;\n"+
	"}\n";

	private final String pSource =
	"precision mediump float;\n"+
	"varying vec2 texture;\n"+
	"uniform sampler2D image;\n"+
	"void main(){\n"+
	"gl_FragColor = texture2D(image,texture);\n"+
	"}\n";
	
}
