package bogo.kaayo.graphics.model;

import bogo.kaayo.Rb;
import bogo.kaayo.graphics.Camera;
import bogo.kaayo.graphics.shaders.Shader;

public class ModelRenderer{
	private Camera cam;
	private Model model;
	private Shader shader;
	
	public void begin(Camera cam){
		this.cam = cam;
		Rb.GL20.glEnable(Rb.GL20.GL_DEPTH_TEST);
		//Rb.GL20.glEnable(Rb.GL20.GL_CULL_FACE);
		//Rb.GL20.glCullFace(Rb.GL20.GL_FRONT);
	}
	
	public void render(ModelEntity entity){
		render(entity,Rb.GL20.GL_TRIANGLES);
	}
	
	public void render(ModelEntity entity, int mode){
		model = entity.model;
		shader = model.getShader();
		
		shader.start();
		
		shader.loadAttribute("vertices",3,Rb.GL20.GL_FLOAT,Rb.D3D*Rb.FLOAT_SIZE_BYTES,model.getMesh().vertexBuffer);
		shader.loadAttribute("textures",3,Rb.GL20.GL_FLOAT,Rb.D3D*Rb.FLOAT_SIZE_BYTES,model.getMesh().textureBuffer);
		shader.loadAttribute("normals",3,Rb.GL20.GL_FLOAT,Rb.D3D*Rb.FLOAT_SIZE_BYTES,model.getMesh().normalBuffer);
		
		shader.loadUniformMatrix4("transformation",entity.getTransformationMatrix());
		shader.loadUniformMatrix4("projection",cam.getProjection());
		shader.loadUniformMatrix4("view",cam.getView());
		shader.loadUniformVector3("lightPos",entity.light.getLightPosition());
		
		Rb.GL20.glDrawElements(mode,entity.model.getMesh().indices.length,Rb.GL20.GL_UNSIGNED_SHORT,entity.model.getMesh().indexBuffer);
		shader.stop();
		
		shader = null;
		model = null;
	}
	
	public void end(){
		cam = null;
		Rb.GL20.glDisable(Rb.GL20.GL_DEPTH_TEST);
		//Rb.GL20.glDisable(Rb.GL20.GL_CULL_FACE);
	}
	
}
