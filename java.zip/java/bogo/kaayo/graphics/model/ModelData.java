package bogo.kaayo.graphics.model;

import bogo.kaayo.graphics.Mesh;

public class ModelData{
	public Mesh mesh;
	public Animation animation;
	
	public ModelData(Mesh m){
		mesh = m;
	}
	
}
