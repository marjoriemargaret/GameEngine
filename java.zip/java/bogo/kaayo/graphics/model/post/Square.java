package bogo.kaayo.graphics.model.post;

import bogo.kaayo.graphics.Mesh;
import bogo.kaayo.math.Vector3f;
import bogo.kaayo.graphics.shaders.Shader;
import bogo.kaayo.Rb;
import bogo.kaayo.graphics.shaders.MaterialShader;
import bogo.kaayo.graphics.model.Model;
import bogo.kaayo.graphics.model.ModelData;

public class Square extends Model{

	public Square(float width, float depth, Vector3f color){
		super(getData(width,depth,color),new MaterialShader());
	}

	private static ModelData getData(float width, float depth, Vector3f color){
		Mesh mesh = new Mesh();

		mesh.vertices = new float[]{
			-width/2, 0, -depth/2,
			width/2, 0, -depth/2,
			width/2, 0, depth/2,
			-width/2, 0, depth/2
		};
		mesh.textures = new float[]{
			color.x, color.y, color.z,
			color.x, color.y, color.z,
			color.x, color.y, color.z,
			color.x, color.y, color.z
		};
		mesh.normals = new float[]{
			0, 1, 0,
			0, 1, 0
		};
		mesh.indices = new short[]{
			0, 1, 2,
			0, 2, 3
		};
		mesh.bindAll();

		return new ModelData(mesh);
	}

}
