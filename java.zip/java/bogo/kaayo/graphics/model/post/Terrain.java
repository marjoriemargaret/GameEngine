package bogo.kaayo.graphics.model.post;

import bogo.kaayo.files.FileHandle;
import android.graphics.*;
import bogo.kaayo.graphics.Mesh;
import bogo.kaayo.math.Vector3f;
import bogo.kaayo.graphics.model.Model;
import bogo.kaayo.graphics.shaders.BlendShader;
import bogo.kaayo.graphics.model.ModelData;

public class Terrain extends Model{
	private static final int SIZE = 2000;
	private static final float maxHeight = 70;
	private static final float maxPixel = 256 * 256 * 256;
	
	public Terrain(FileHandle texture, FileHandle map){
		super(generateTerrain(map),new BlendShader(texture));
	}
	
	private static ModelData generateTerrain(FileHandle map){
		Bitmap image = BitmapFactory.decodeStream(map.read());
		int vertexCount = image.getHeight();

		Mesh mesh = new Mesh();
		int count = vertexCount * vertexCount;
		mesh.vertices = new float[count * 3];
		mesh.textures = new float[count * 3];
		mesh.normals = new float[count * 3];
		mesh.indices = new short[6 * (vertexCount-1) * vertexCount];
		int vertexPointer = 0;
		for(int i=0; i<vertexCount; i++){
			for(int j=0; j<vertexCount; j++){
				mesh.vertices[vertexPointer*3] = (SIZE/2)-((float)i/(vertexCount-1)*SIZE);
				mesh.vertices[vertexPointer*3+1] = getHeight(i,j,image);
				mesh.vertices[vertexPointer*3+2] = (SIZE/2)-((float)j/(vertexCount-1)*SIZE);
				mesh.textures[vertexPointer*3] = (float)i/(vertexCount-1);
				mesh.textures[vertexPointer*3+1] = (float)j/(vertexCount-1);
				mesh.textures[vertexPointer*3+2] = 0;
				Vector3f normal = calculateNormal(i,j,image);
				mesh.normals[vertexPointer*3] = normal.x;
				mesh.normals[vertexPointer*3] = normal.y;
				mesh.normals[vertexPointer*3] = normal.z;
				vertexPointer++;
			}
		}
		int pointer = 0;
		for(int i=0; i<vertexCount-1; i++){
			for(int j=0; j<vertexCount-1; j++){
				int topLeft = (i * vertexCount) + j;
				int topRight = topLeft + 1;
				int bottomLeft = ((i+1) * vertexCount) + j;
				int bottomRight = bottomLeft + 1;
				mesh.indices[pointer++] = (short)topLeft;
				mesh.indices[pointer++] = (short)bottomLeft;
				mesh.indices[pointer++] = (short)topRight;
				mesh.indices[pointer++] = (short)topRight;
				mesh.indices[pointer++] = (short)bottomLeft;
				mesh.indices[pointer++] = (short)bottomRight;
			}
		}
		mesh.bindAll();
		image.recycle();
		return new ModelData(mesh);
	}
	
	private static float getHeight(int x, int z, Bitmap image){
		if(x<0 || x>=image.getHeight() || z<0 || z>=image.getHeight()) return 0;
		float height = image.getPixel(x,z);
		height += maxPixel/2f;
		height /= maxPixel/2f;
		height *= maxHeight;
		return height;
	}
	
	private static Vector3f calculateNormal(int x, int z, Bitmap img){
		float hL = getHeight(x-1,z,img);
		float hR = getHeight(x+1,z,img);
		float hD = getHeight(x,z-1,img);
		float hU = getHeight(x,z+1,img);
		return new Vector3f(hL-hR,2f,hD-hU).nor();
	}
	
}
