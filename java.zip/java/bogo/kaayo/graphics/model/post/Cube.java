package bogo.kaayo.graphics.model.post;

import bogo.kaayo.graphics.Mesh;

public class Cube{
	
	public Cube(int size){
		Mesh mesh = new Mesh();
		mesh.vertices = new float[]{
			-size, -size, -size,
			size, -size, -size,
			size,  size, -size,
			-size,  size, -size,
			-size, -size,  size,
			size, -size,  size,
			size,  size,  size,
			-size,  size,  size,
		};
		mesh.textures = new float[]{
			
		};
		mesh.indices = new short[]{
			0, 4, 5,    0, 5, 1,
			1, 5, 6,    1, 6, 2,
			2, 6, 7,    2, 7, 3,
			3, 7, 4,    3, 4, 0,
			4, 7, 6,    4, 6, 5,
			3, 0, 1,    3, 1, 2
		};
	}
	
}
