package bogo.kaayo.graphics.model;

import java.nio.*;
import bogo.kaayo.*;
import bogo.kaayo.graphics.*;
import bogo.kaayo.math.*;
import bogo.kaayo.graphics.model.loader.*;
import bogo.kaayo.graphics.shaders.*;
import bogo.kaayo.graphics.model.entities.*;

public class Model{
	private Shader shader;
	private ModelData data;
	
	public Model(ModelData d, Shader s){
		data = d;
		data.mesh.bindAll();
		shader = s;
	}

	public Mesh getMesh(){
		return data.mesh;
	}

	public Shader getShader(){
		return shader;
	}
	
}
