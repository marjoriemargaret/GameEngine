package bogo.kaayo.graphics.model.loader;

public class FbxLoader{
	
	public FbxLoader(){
		
	}
	
}
