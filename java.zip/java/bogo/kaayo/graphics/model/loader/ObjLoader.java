package bogo.kaayo.graphics.model.loader;

import java.io.*;
import bogo.kaayo.graphics.model.Model;
import bogo.kaayo.math.*;
import java.util.*;
import bogo.kaayo.*;
import bogo.kaayo.graphics.shaders.TextureShader;
import bogo.kaayo.graphics.*;
import bogo.kaayo.files.*;
import bogo.kaayo.graphics.model.ModelData;
import bogo.kaayo.graphics.shaders.MaterialShader;

/**
  *
  * This Loader is just for Testing Purposes
  * Use FBXLoader instead
  *
  **/

public class ObjLoader{
	private static ArrayList<Vector3f> vertices;
	private static ArrayList<Vector3f> textures;
	private static ArrayList<Vector3f> normals;
	private static ArrayList<Short> indices;
	private static Mesh mesh;
	
	public static Model load(FileHandle file){
		return load(file,false);
	}
	
	public static Model load(FileHandle file, boolean flipV){
		vertices = new ArrayList<>();
		textures = new ArrayList<>();
		normals = new ArrayList<>();
		indices = new ArrayList<>();
		mesh = new Mesh();
		boolean hasUV = false;
		try{
			String line;
			BufferedReader br = file.getBuffer();

			while((line=br.readLine()) != null){
				String[] tokens = line.split(" ");
				if(tokens[0].equalsIgnoreCase("v")){
					Vector3f vertex = new Vector3f(Float.parseFloat(tokens[1]),Float.parseFloat(tokens[2]),Float.parseFloat(tokens[3]));
					vertices.add(vertex);
				}if(tokens[0].equalsIgnoreCase("vt")){
					Vector3f texture = new Vector3f(Float.parseFloat(tokens[1]),Float.parseFloat(tokens[2]),0);
					textures.add(texture);
					if(!hasUV) hasUV=true;
				}if(tokens[0].equalsIgnoreCase("vn")){
					Vector3f normal = new Vector3f(Float.parseFloat(tokens[1]),Float.parseFloat(tokens[2]),Float.parseFloat(tokens[3]));
					normals.add(normal);
				}if(tokens[0].equalsIgnoreCase("f")){
					mesh.vertices = new float[vertices.size()*3];
					mesh.textures = new float[vertices.size()*3];
					mesh.normals = new float[vertices.size()*3];
					break;
				}
			}
			
			if(!hasUV){
				textures.add(new Vector3f(1,1,1));
			}

			br = file.getBuffer();
			while((line = br.readLine()) != null){
				String[] tokens = line.split(" ");
				if(tokens[0].equalsIgnoreCase("f")){
					String[] part1 = tokens[1].split("/");
					parse(Integer.parseInt(part1[0])-1,hasUV?Integer.parseInt(part1[1])-1:0,Integer.parseInt(part1[2])-1,flipV);

					String[] part2 = tokens[2].split("/");
					parse(Integer.parseInt(part2[0])-1,hasUV?Integer.parseInt(part2[1])-1:0,Integer.parseInt(part2[2])-1,flipV);

					String[] part3 = tokens[3].split("/");
					parse(Integer.parseInt(part3[0])-1,hasUV?Integer.parseInt(part3[1])-1:0,Integer.parseInt(part3[2])-1,flipV);
				}
			}

			mesh.indices = new short[indices.size()];
			for(int i=0; i<indices.size(); i++){
				mesh.indices[i] = indices.get(i);
			}
			for(int i=0; i<vertices.size(); i++){
				Vector3f vert = vertices.get(i);
				mesh.vertices[i*3] = vert.x;
				mesh.vertices[i*3+1] = vert.y;
				mesh.vertices[i*3+2] = vert.z;
			}
			ModelData data = new ModelData(mesh);

			return new Model(data,
			hasUV?new TextureShader(file.getFile().getPath().substring(0,file.getFile().getPath().length()-3)+"jpg"):
			new MaterialShader());
		}catch (Exception e){
			throw new RbException(e);
		}
	}
	
	private static void parse(int vertexIndex, int textureIndex, int normalIndex, boolean flipV){
		indices.add((short)vertexIndex);
		mesh.textures[vertexIndex*3] = textures.get(textureIndex).x;
		mesh.textures[vertexIndex*3+1] = flipV==true?1-textures.get(textureIndex).y:textures.get(textureIndex).y;
		mesh.textures[vertexIndex*3+2] = 0;
		mesh.normals[vertexIndex*3] = normals.get(normalIndex).x;
		mesh.normals[vertexIndex*3+1] = normals.get(normalIndex).y;
		mesh.normals[vertexIndex*3+2] = normals.get(normalIndex).z;
	}
	
}
