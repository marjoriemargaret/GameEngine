package bogo.kaayo.graphics.model;

import bogo.kaayo.Rb;
import bogo.kaayo.RbException;
import bogo.kaayo.math.Vector3f;
import java.util.ArrayList;
import bogo.kaayo.graphics.model.entities.Light;
import bogo.kaayo.math.Matrix4f;

public class ModelEntity{
	public Model model;
	public Light light;
	
	private float[] translation = new float[16];
	private float[] orientation = new float[16];
	private float[] formation = new float[16];
	
	public ModelEntity(Model m, Light l){
		model = m;
		light = l;
		
		Matrix4f.setIdentityM(translation,0);
		Matrix4f.setIdentityM(orientation,0);
		Matrix4f.setIdentityM(formation,0);
	}
	
	public void translate(float x, float y, float z){
		Matrix4f.translateM(translation,0,x,y,z);
	}
	
	public void setTranslation(float x, float y, float z){
		translation[12] = x;
		translation[13] = y;
		translation[14] = z;
	}
	
	public void setTranslation(Vector3f position){
		setTranslation(position.x,position.y,position.z);
	}
	
	public Vector3f position(){
		return new Vector3f(translation[12],translation[13],translation[14]);
	}
	
	public void rotate(float w, float x, float y, float z){
		Matrix4f.rotateM(orientation,0,w,x,y,z);
	}
	
	public void scale(float x, float y, float z){
		Matrix4f.scaleM(formation,0,x,y,z);
	}
	
	public float[] getTransformationMatrix(){
		float[] combined = new float[16];
		Matrix4f.setIdentityM(combined,0);

		Matrix4f.multiplyMM(combined,0,translation,0,orientation,0);
		Matrix4f.multiplyMM(combined,0,formation,0,combined,0);

		return combined;
	}
	
}
