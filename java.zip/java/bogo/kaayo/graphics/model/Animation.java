package bogo.kaayo.graphics.model;

public class Animation{
}
