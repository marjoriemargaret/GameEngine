package bogo.kaayo.graphics.model.entities;

import bogo.kaayo.Rb;
import bogo.kaayo.math.Vector3f;

public class Light{
	private Vector3f position = new Vector3f();
	
	public Light(float px, float py, float pz){
		position.set(px,py,pz);
	}
	
	public Vector3f getLightPosition(){
		return position;
	}
	
}
