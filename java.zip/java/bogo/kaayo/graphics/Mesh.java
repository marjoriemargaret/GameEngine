package bogo.kaayo.graphics;

import java.nio.FloatBuffer;
import java.nio.ShortBuffer;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import bogo.kaayo.Rb;

public class Mesh{
	public float[] vertices;
	public float[] textures;
	public float[] normals;
	public short[] indices;
	
	public FloatBuffer vertexBuffer;
	public FloatBuffer textureBuffer;
	public FloatBuffer normalBuffer;
	public ShortBuffer indexBuffer;
	
	public void bindVertices(){
		vertexBuffer = parseFloat(vertices);
	}
	
	public void bindTextures(){
		textureBuffer = parseFloat(textures);
	}
	
	public void bindNormals(){
		normalBuffer = parseFloat(normals);
	}
	
	public void bindIndices(){
		indexBuffer = parseShort(indices);
	}
	
	public void bindAll(){
		bindVertices();
		bindTextures();
		bindNormals();
		bindIndices();
	}
	
	public void unbindAll(){
		vertices = null;
		textures = null;
		normals = null;
		indices = null;
		vertexBuffer = null;
		textureBuffer = null;
		normalBuffer = null;
		indexBuffer = null;
	}
	
	private FloatBuffer parseFloat(float[] values){
		FloatBuffer tmp = ByteBuffer.allocateDirect(values.length*Rb.FLOAT_SIZE_BYTES).order(ByteOrder.nativeOrder()).asFloatBuffer();
		for(float f : values){
			tmp.put(f);
		}
		tmp.position(0);
		return tmp;
	}

	private ShortBuffer parseShort(short[] values){
		ShortBuffer tmp = ByteBuffer.allocateDirect(values.length*Rb.SHORT_SIZE_BYTES).order(ByteOrder.nativeOrder()).asShortBuffer();
		for(short s : values){
			tmp.put(s);
		}
		tmp.position(0);
		return tmp;
	}
	
}
