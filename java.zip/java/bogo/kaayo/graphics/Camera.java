package bogo.kaayo.graphics;

import bogo.kaayo.Rb;
import bogo.kaayo.math.Vector3f;
import bogo.kaayo.math.Matrix4f;
import bogo.kaayo.math.PickRay;

public class Camera{
	public int vWidth;
	public int vHeight;
	
	public float fov = 67f;
	public float near = 1f;
	public float far = 100f;
	boolean perspective = false;
	
	private float[] projection = new float[16];
	private float[] inverted = new float[16];
	
	public Camera(){
		super();
		Matrix4f.setIdentityM(projection,0);
	}
	
	public Camera setToPersp(){
		perspective = true;
		return this;
	}
	
	public Camera setToOrtho(){
		perspective = false;
		return this;
	}
	
	public void update(boolean updateFrustrum, int width, int height){
		vWidth = width;
		vHeight = height;
		update(updateFrustrum);
	}
	
	public void update(){
		update(true);
	}
	
	public void update(boolean updateFrustrum){
		float aspect = (float)vWidth/vHeight;
		if(perspective) Matrix4f.perspectiveM(projection,0,fov,aspect,near,far);
		else Matrix4f.orthoM(projection,0,-aspect,aspect,-1,1,near,far);
		if(updateFrustrum){
			Matrix4f.invertM(inverted,0,projection,0);
		}
	}
	
	public float[] getProjection(){
		return projection;
	}
	
	public float[] getInverted(){
		return inverted;
	}
	
	private Vector3f up = new Vector3f(0,1,0);
	private Vector3f direction = new Vector3f(0,0,-1);
	public Vector3f position = new Vector3f();

	public void translate(float x, float y, float z){
		position.add(x,y,z);
	}

	public void rotate(float w, float x, float y, float z){
		direction.rotate(w,x,y,z);
		up.rotate(w,x,y,z);
	}

	Vector3f tmp = new Vector3f();
	public void rotateAround(Vector3f point, float w, float x, float y, float z){
		tmp.set(point);
		tmp.sub(position);
		translate(tmp.x, tmp.y, tmp.z);
		rotate(w,x,y,z);
		tmp.rotate(w,x,y,z);
		translate(-tmp.x, -tmp.y, -tmp.z);

	}

	public float[] getView(){
		float[] combined = new float[16];
		Matrix4f.setIdentityM(combined,0);
		tmp.set(position).add(direction);
		Matrix4f.setLookAtM(combined,0,position.x,position.y,position.z,tmp.x,tmp.y,tmp.z,up.x,up.y,up.z);
		return combined;
	}

	public void lookAt(float x, float y, float z){
		tmp.set(x, y, z).sub(position).nor();
		if (!tmp.isZero()) {
			float dot = tmp.dot(up); // up and direction must ALWAYS be orthonormal vectors
			if (Math.abs(dot - 1) < 0.000000001f) {
				// Collinear
				up.set(direction).scl(-1);
			} else if (Math.abs(dot + 1) < 0.000000001f) {
				// Collinear opposite
				up.set(direction);
			}
			direction.set(tmp);
			normalizeUp();
		}
	}
	
	public void lookAt(Vector3f eye){
		lookAt(eye.x,eye.y,eye.z);
	}

	public void normalizeUp(){
		tmp.set(direction).crs(up).nor();
		up.set(tmp).crs(direction).nor();
	}

	/* Other Utilities */

	public Vector3f unproject (Vector3f screenCoords, float viewportX, float viewportY, float viewportWidth, float viewportHeight) {
		float x = screenCoords.x, y = screenCoords.y;
		x = x - viewportX;
		y = Rb.graphics.height() - y - 1;
		y = y - viewportY;
		screenCoords.x = (2 * x) / viewportWidth - 1;
		screenCoords.y = (2 * y) / viewportHeight - 1;
		screenCoords.z = 2 * screenCoords.z - 1;
		screenCoords.prj(getInverted());
		return screenCoords;
	}

	private PickRay ray = new PickRay();
	public PickRay getPickRay (float screenX, float screenY, float viewportX, float viewportY, float viewportWidth, float viewportHeight) {
		unproject(ray.origin.set(screenX, screenY, 0), viewportX, viewportY, viewportWidth, viewportHeight);
		unproject(ray.direction.set(screenX, screenY, 1), viewportX, viewportY, viewportWidth, viewportHeight);
		ray.direction.sub(ray.origin).nor();
		return ray;
	}

	public PickRay getPickRay (float screenX, float screenY) {
		return getPickRay(screenX, screenY, 0, 0, Rb.graphics.width(), Rb.graphics.height());
	}
	
}
