package bogo.kaayo;

public class RbException extends RuntimeException{
	
	public RbException(Throwable th){
		super(th);
		printStackTrace(System.out);
		System.exit(0);
	}
	
	public RbException(String msg){
		super(msg);
		printStackTrace(System.out);
		System.exit(0);
	}
	
}
