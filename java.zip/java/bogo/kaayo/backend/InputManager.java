package bogo.kaayo.backend;

import android.view.View.OnTouchListener;
import android.view.MotionEvent;
import android.view.View;
import bogo.kaayo.Rb;
import bogo.kaayo.input.InputListener;
import bogo.kaayo.Input;
import java.util.ArrayList;

public class InputManager implements Input, OnTouchListener{
	private ArrayList<InputListener> inputs = new ArrayList<>();
	private long time;
	private long delay = 10;
	
	public InputManager(View v){
		v.setOnTouchListener(this);
	}

	@Override
	public void addInputProcessor(InputListener listener){
		inputs.add(listener);
	}

	@Override
	public void setTouchDelay(long millis){
		delay = millis;
	}
	
	@Override
	public boolean onTouch(View p1, MotionEvent p2){
		InputListener.Event e = new InputListener.Event();
		e.setCount(p2.getPointerCount());
		for(int i=0; i<p2.getPointerCount(); i++){
			e.set(i,p2.getX(i),p2.getY(i));
		}
		for(InputListener input : inputs){
			switch(p2.getAction()){
				case DOWN:
					time = System.currentTimeMillis();
					input.justTouch(e);
					break;
				case UP:
					time = 0;
					input.touchUp(e);
					break;
				case HOLD:
					if(System.currentTimeMillis()>time+delay) input.touchDown(e);
					break;
			}
		}
		return true;
	}
	
	private final int DOWN = 0;
	private final int UP = 1;
	private final int HOLD = 2;
	
}
