package bogo.kaayo.backend;

import bogo.kaayo.Files;
import bogo.kaayo.files.FileHandle;
import java.io.File;
import java.io.IOException;
import bogo.kaayo.RbException;

public class Resources implements Files{
	private String device = null;
	private String obb = null;
	
	public Resources setDevicePath(String path){
		device = path+"/";
		return this;
	}

	public Resources setOBBPath(String path){
		obb = path+"/";
		return this;
	}

	@Override
	public FileHandle classpath(String path){
		return new FileHandle("/",FileHandle.Type.CLASSPATH);
	}

	@Override
	public FileHandle device(String path){
		return new FileHandle(device+path,FileHandle.Type.DEVICE);
	}
	
	@Override
	public FileHandle obb(String path){
		return new FileHandle(obb+path,FileHandle.Type.OBB);
	}
	
}
