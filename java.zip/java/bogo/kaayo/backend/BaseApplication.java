package bogo.kaayo.backend;

import bogo.kaayo.GameListener;
import android.app.Activity;
import java.io.PrintStream;
import java.io.File;
import java.io.FileNotFoundException;
import bogo.kaayo.Rb;
import android.app.ActivityManager;
import android.content.pm.ConfigurationInfo;
import bogo.kaayo.RbException;
import android.os.Environment;

public class BaseApplication extends Activity{
	GameRenderer renderer;
	boolean configured = false;
	
	private final int FEATURE_NO_TITLE = 1;
	
	public void configure(){
		try{
			configure("/storage/emulated/0/game/logs.txt");
			configured = true;
		}catch (FileNotFoundException e){}
	}
	
	public void configure(String logPath) throws FileNotFoundException{
		requestWindowFeature(FEATURE_NO_TITLE);
		System.setOut(new PrintStream(new File(logPath)));
	}
	
	private boolean pwedeGL20(){
		ActivityManager am = (ActivityManager) getSystemService(ACTIVITY_SERVICE);
		ConfigurationInfo info = am.getDeviceConfigurationInfo();
		return info.reqGlEsVersion >= 0x20000;
	}
	
	public void startGame(GameListener game, int splash){
		if(!pwedeGL20()) throw new RbException("openGL error: this game needs to run opengl2.0");
		if(!configured) configure();
		Rb.files = new Resources().setOBBPath(getObbDir().getPath()).setDevicePath(Environment.getExternalStorageDirectory().getPath());
		Rb.graphics = renderer = new GameRenderer(game,this,splash);
		Rb.input = new InputManager(renderer.getView());
	}

	@Override
	public void onBackPressed(){
		System.out.println("back");
		super.onBackPressed();
	}

	@Override
	protected void onPause(){
		System.out.println("paused");
		renderer.onPause();
		super.onPause();
	}

	@Override
	protected void onResume(){
		System.out.println("resumed");
		renderer.onResume();
		super.onResume();
	}
	
}
