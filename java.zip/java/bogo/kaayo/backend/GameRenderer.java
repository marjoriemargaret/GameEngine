package bogo.kaayo.backend;

import android.opengl.GLSurfaceView;
import android.app.Activity;
import bogo.kaayo.GameListener;
import bogo.kaayo.Rb;
import bogo.kaayo.Graphics;

import android.app.Dialog;
import bogo.kaayo.RbException;

public class GameRenderer implements GLSurfaceView.Renderer, Graphics{
	private GameListener game;
	private GLSurfaceView view;
	
	private Dialog loader;
	private long time;
	
	public GameRenderer(GameListener game, Activity app, int splash){
		view = new GLSurfaceView(app.getApplication());
		view.setEGLContextClientVersion(2);
		view.setRenderer(this);
		view.setFocusable(true);
		view.setFocusableInTouchMode(true);
		app.setContentView(view);
		this.game = game;
		
		loader = new Dialog(app,android.R.style.Theme_Black_NoTitleBar_Fullscreen);
		loader.setContentView(splash);
		loader.show();
		time = System.currentTimeMillis();
	}
	
	@Override
	public void onSurfaceCreated(javax.microedition.khronos.opengles.GL10 unused, javax.microedition.khronos.egl.EGLConfig p){
		game.create();
		final long currTime = System.currentTimeMillis();
		try{
			if (currTime < time + 3000) Thread.sleep(time + 3000 - currTime);
		}catch (InterruptedException e){
			throw new RbException(e);
		}
		loader.dismiss();
	}

	@Override
	public void onSurfaceChanged(javax.microedition.khronos.opengles.GL10 unused, int p1, int p2){
		viewportWidth = p1;
		viewportHeight = p2;
		unused.glViewport(0,0,p1,p2);
		game.resize(p1,p2);
	}

	@Override
	public void onDrawFrame(javax.microedition.khronos.opengles.GL10 unused){
		synchronized(this){
			long time = System.nanoTime();
			deltaTime = (time-lastFrameTime)/1000000000.0f;
			lastFrameTime = time;

			game.draw();

			if(time-frameStart > 1000000000){
				fps = frames;
				frames = 0;
				frameStart = time;
			}
			frames++;
		}
	}
	
	public void onPause(){
		view.onPause();
		game.pause();
	}
	
	public void onResume(){
		view.onResume();
		game.resume();
	}
	
	/* Graphics */
	
	private int viewportWidth = 0;
	private int viewportHeight = 0;
	private float deltaTime =0;
	private int fps = 0;
	
	private int frames =0;
	private long frameStart = System.nanoTime();
	private long lastFrameTime = System.nanoTime();
	
	
	@Override
	public int width(){
		return viewportWidth;
	}
	
	@Override
	public int height(){
		return viewportHeight;
	}
	
	public GLSurfaceView getView(){
		return view;
	}

	@Override
	public float deltaTime(){
		return deltaTime;
	}

	@Override
	public int FPS(){
		return fps;
	}
	
}
