package bogo.kaayo;

import bogo.kaayo.files.FileHandle;

public interface Files{
	
	public FileHandle classpath(String path);
	
	public FileHandle device(String path);
	
	public FileHandle obb(String path);
	
}
