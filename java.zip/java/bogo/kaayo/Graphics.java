package bogo.kaayo;

public interface Graphics{
	
	public int width();
	
	public int height();
	
	public float deltaTime();
	
	public int FPS();
	
}
