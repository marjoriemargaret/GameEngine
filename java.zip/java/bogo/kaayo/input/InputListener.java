package bogo.kaayo.input;

public interface InputListener{
	
	public void touchUp(Event e);
	
	public void touchDown(Event e);
	
	public void justTouch(Event e);
	
	public class Event{
		private float[] px = new float[16];
		private float[] py = new float[16];
		private int count = 0;
		
		public void set(int p, float x, float y){
			px[p] = x;
			py[p] = y;
		}
		
		public void setCount(int p){
			count = p;
		}
		
		public float getX(int p){
			return px[p];
		}
		
		public float getY(int p){
			return py[p];
		}
		
		public int getPointerCount(){
			return count;
		}
		
	}
	
}
