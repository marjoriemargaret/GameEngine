package bogo.kaayo.files;

import java.io.InputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import bogo.kaayo.RbException;
import java.io.BufferedReader;
import java.io.FileReader;

public class FileHandle{
	
	public static enum Type{
		ABSOLUTE,
		CLASSPATH,
		DEVICE,
		OBB
	}
	
	private String filePath;
	private Type fileType;
	
	public FileHandle(String path){
		filePath = path;
		fileType = Type.ABSOLUTE;
	}
	
	public FileHandle(String path, Type t){
		filePath = path;
		fileType = t;
	}
	
	public InputStream read(){
		try{
			return new FileInputStream(getFile());
		}catch (FileNotFoundException e){
			throw new RbException(e);
		}
	}
	
	public File getFile(){
		return new File(filePath);
	}
	
	public BufferedReader getBuffer(){
		try{
			return new BufferedReader(new FileReader(getFile()));
		}catch (FileNotFoundException e){
			throw new RbException(e);
		}
	}
	
}
