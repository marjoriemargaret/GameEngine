package bogo.kaayo.physics;

import java.util.ArrayList;
import bogo.kaayo.math.Plane;
import bogo.kaayo.math.Vector3f;

public class StaticObject{
	private ArrayList<Plane> planes = new ArrayList<>();
	
	public StaticObject(float[] vertices, short[] indices){
		calculateVertices(vertices,indices);
	}
	
	Plane tmpPlane;
	void calculateVertices(float[] vertices, short[] indices){
		for(int i=0; i<indices.length; i+=3){
			tmpPlane = new Plane(
			new Vector3f(vertices[indices[i]*3],vertices[indices[i]*3+1],vertices[indices[i]*3+2]),
			new Vector3f(vertices[indices[i+1]*3],vertices[indices[i+1]*3+1],vertices[indices[i+1]*3+2]),
			new Vector3f(vertices[indices[i+2]*3],vertices[indices[i+2]*3+1],vertices[indices[i+2]*3+2]));
			planes.add(tmpPlane);
		}
	}
	
	public ArrayList<Plane> getPlanes(){
		return planes;
	}
	
}
