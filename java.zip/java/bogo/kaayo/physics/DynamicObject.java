package bogo.kaayo.physics;

import bogo.kaayo.math.Vector3f;

public class DynamicObject{
	public Vector3f position = new Vector3f();
	public Vector3f velocity = new Vector3f();
	
	public DynamicObject(){}
	
	public DynamicObject(final Vector3f position){
		this.position.set(position);
	}
	
}
