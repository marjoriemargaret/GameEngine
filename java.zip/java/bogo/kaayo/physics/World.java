package bogo.kaayo.physics;

import bogo.kaayo.math.Vector3f;
import java.util.ArrayList;
import bogo.kaayo.math.Vector3f;
import bogo.kaayo.math.Plane;
import bogo.kaayo.math.Intersector;
import java.util.*;

public class World{
	private Vector3f gravity = new Vector3f();
	public HashMap<String,DynamicObject> dynamics = new HashMap<>();
	public ArrayList<StaticObject> statics = new ArrayList<>();
	
	public World(float gravityX, float gravityY, float gravityZ){
		gravity.set(gravityX,gravityY,gravityZ);
	}
	
	public void add(String identifier,DynamicObject body){
		dynamics.put(identifier,body);
	}
	public void add(StaticObject body){
		statics.add(body);
	}
	
	public void step(float deltaTime){
		if(!statics.isEmpty() || !dynamics.isEmpty()){
			for(DynamicObject DO : dynamics.values()){
				DO.position.add(new Vector3f(deltaTime,deltaTime,deltaTime).mul(DO.velocity));
				DO.velocity.sub(new Vector3f(deltaTime,deltaTime,deltaTime).mul(gravity));
				for(StaticObject SO : statics){
					for(Plane p : SO.getPlanes()){
						if(Intersector.intersectSegmentPlane(DO.position,new Vector3f(DO.position).add(0,10,0),p,null)){
							DO.position.y+=0.001f;
						}
					}
				}
			}
		}
	}
	
}
