package bogo.kaayo;

public class Rb extends OpenGL{
	public static int INT_SIZE_BYTES = 4;
	public static int FLOAT_SIZE_BYTES = 4;
	public static int SHORT_SIZE_BYTES = 2;
	public static int D2D = 2;
	public static int D3D = 3;
	
	public static Graphics graphics;
	
	public static Input input;
	
	public static Files files;
	
}
