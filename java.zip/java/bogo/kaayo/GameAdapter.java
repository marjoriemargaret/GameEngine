package bogo.kaayo;

import bogo.kaayo.input.InputListener;
import bogo.kaayo.input.InputListener.Event;

public abstract class GameAdapter implements GameListener, InputListener{

	@Override
	public void pause(){
		// TODO: Implement this method
	}

	@Override
	public void resume(){
		// TODO: Implement this method
	}
	
	@Override
	public void justTouch(Event e){
		// TODO: Implement this method
	}

	@Override
	public void touchUp(Event e){
		// TODO: Implement this method
	}

	@Override
	public void touchDown(Event e){
		// TODO: Implement this method
	}
	
}
