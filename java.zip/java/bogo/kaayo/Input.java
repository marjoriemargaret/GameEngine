package bogo.kaayo;

import bogo.kaayo.input.InputListener;

public interface Input{
	
	public void addInputProcessor(InputListener listener);
	
	public void setTouchDelay(long millis);
	
}
