package bogo.kaayo;

public interface GameListener{
	
	public void create();
	
	public void draw();
	
	public void resize(int width, int height);
	
	public void pause();
	
	public void resume();
	
}
