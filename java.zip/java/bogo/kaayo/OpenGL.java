package bogo.kaayo;

import android.graphics.*;
import android.opengl.*;
import bogo.kaayo.math.*;

public class OpenGL{
	public static android.opengl.GLES20 GL20;
	public static class GLU{
		
		public static void load(String path) throws Exception{
			Bitmap image =  BitmapFactory.decodeFile(path);
			GLUtils.texImage2D(Rb.GL20.GL_TEXTURE_2D, 0, image, 0);
			image.recycle();
		}
		
		public static Vector3f getNormalizedDeviceCoords(float px, float py){
			float x = (2.0f*px) / Rb.graphics.width() - 1;
			float y = (2.0f*py) / Rb.graphics.height() - 1;
			return new Vector3f(x,y,0);
		}
		
		public static float clip(float p1, float p2){
			return 2*p1/p2;
		}
		
	}
}
