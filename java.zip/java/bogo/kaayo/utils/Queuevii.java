package bogo.kaayo.utils;

public class Queuevii<T>{
	public T[] objects = null;
	private int capacity;
	public int size = 0;
	
	public Queuevii(int max){
		capacity = max;
	}
	
	public boolean enqueue(T ref){
		if(objects == null) objects = (T[])java.lang.reflect.Array.newInstance(ref.getClass(),capacity);
		if(size<capacity){
			objects[size] = ref;
			size++;
			return true;
		}else{
			if(dequeue()){
				enqueue(ref);
			}
		}
		return false;
	}
	
	public boolean dequeue(T res){
		if(size>0){
			res = objects[0];
			dequeue();
		}
		return false;
	}
	
	private boolean dequeue(){
		if(size>0){
			for(int i=0; i<size-1; i++){
				objects[i] = objects[i+1];
			}
			size--;
		}
		return false;
	}
	
	public T getHead(){
		return objects[size-1<0?0:size-1];
	}
	
	public T getTail(){
		return objects[0];
	}
	
	public void clear(){
		while(size>0){
			dequeue();
		}
	}
	
	public int getIndex(){
		return size;
	}
	
}
