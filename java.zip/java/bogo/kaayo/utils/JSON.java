package bogo.kaayo.utils;

import org.json.JSONArray;
import bogo.kaayo.files.FileHandle;
import java.io.BufferedReader;
import java.io.IOException;
import org.json.JSONException;
import bogo.kaayo.RbException;
import org.json.JSONObject;

public class JSON{
	
	public static JSONArray toArray(FileHandle jsonfile){
		try{
			String jsonstr = "";
			BufferedReader br = jsonfile.getBuffer();
			String line = null;
			try{
				while ((line = br.readLine()) != null){
					jsonstr += line;
				}
			}catch (IOException e){
				throw new RbException(e);
			}
			return new JSONArray(jsonstr);
		}catch (JSONException e){
			throw new RbException(e);
		}
	}
	
	public static JSONObject toObjects(FileHandle jsonfile){
		try{
			String jsonstr = "";
			BufferedReader br = jsonfile.getBuffer();
			String line = null;
			try{
				while ((line = br.readLine()) != null){
					jsonstr += line;
				}
			}catch (IOException e){
				throw new RbException(e);
			}
			return new JSONObject(jsonstr);
		}catch (JSONException e){
			throw new RbException(e);
		}
	}
	
}
